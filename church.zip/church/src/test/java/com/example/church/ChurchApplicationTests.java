package com.example.church;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChurchApplicationTests {

	@Test
	void contextLoads() {
	}

}
